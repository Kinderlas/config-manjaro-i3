#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
###parse("File Header.java")

/**
 * Created @ ${YEAR}-${MONTH}-${DAY} ${TIME}
 *
 * @author Hu Shuo(shuohu213701@sohu-inc.com
 * @version 1.0
 */
public enum ${NAME} {
}
