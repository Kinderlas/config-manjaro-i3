/**
 * Created @ ${YEAR}-${MONTH}-${DAY} ${TIME}
 *
 * @author Chen Xiang(xiangchen210892@sohu-inc.com)
 * @version 1.0
 */

#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end