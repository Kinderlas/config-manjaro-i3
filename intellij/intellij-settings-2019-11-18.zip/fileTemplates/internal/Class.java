/*
  Copyright ${YEAR} Sohu.com Inc. All Rights Reserved.
 */

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
###parse("File Header.java")

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created @ ${YEAR}-${MONTH}-${DAY} ${TIME}
 *
 * @author Hu Shuo(shuohu213701@sohu-inc.com)
 * @version 1.0
 */
public class ${NAME} {
    private static final Logger logger = LoggerFactory.getLogger(${NAME}.class);
    
}