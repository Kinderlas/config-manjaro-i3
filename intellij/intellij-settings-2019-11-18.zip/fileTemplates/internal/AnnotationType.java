#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
###parse("File Header.java")

/**
 * Created @ ${YEAR}-${MONTH}-${DAY} ${TIME}
 *
 * @author Chen Xiang(xiangchen210892@sohu-inc.com)
 * @version 1.0
 */
public @interface ${NAME} {
}
