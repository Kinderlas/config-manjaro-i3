/*
  Copyright ${YEAR} Sohu.com Inc. All Rights Reserved.
 */

/**
 * Created @ ${YEAR}-${MONTH}-${DAY} ${TIME}
 *
 * @author Hu Shuo(shuohu213701@sohu-inc.com)
 * @version 1.0
 */