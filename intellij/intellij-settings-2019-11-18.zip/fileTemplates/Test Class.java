/*
  Copyright ${YEAR} Sohu.com Inc. All Rights Reserved.
 */

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
###parse("File Header.java")

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created @ ${YEAR}-${MONTH}-${DAY} ${TIME}
 *
 * @author Chen Xiang(xiangchen210892@sohu-inc.com)
 * @version 1.0
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath*:spring/*.xml"})
public class ${NAME} {
    private static final Logger logger = LoggerFactory.getLogger(${NAME}.class);
    
}